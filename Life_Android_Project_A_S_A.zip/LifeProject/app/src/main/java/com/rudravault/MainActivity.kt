package com.rudravault

import android.app.*
import android.os.*
import android.content.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.*
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

data class VaultItem(val id:String,val name:String,val type:String,val path:String,val originalUri:String?,var originalDeleted:Boolean)

class MainActivity: AppCompatActivity(){
    private lateinit var box:LinearLayout
    private val prefs by lazy { getSharedPreferences("vault",0) }

    private val picker=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){ list->
        list?.forEach { moveIntoVault(it, currentType) }
        refreshDashboard()
    }
    private var currentType="other"

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        if(!prefs.getBoolean("setup",false)) setup() else login()
    }

    private fun setup(){
        box=base()
        title("🔐 Life")
        text("Create your PIN/password. Fingerprint uses your phone's registered biometric.")
        val p=EditText(this).apply{hint="New PIN / Password"; inputType=0x81}
        val c=EditText(this).apply{hint="Confirm"; inputType=0x81}
        box.addView(p);box.addView(c)
        val b=Button(this).apply{text="Create Life Vault"}
        box.addView(b)
        b.setOnClickListener{
            if(p.text.length<4||p.text.toString()!=c.text.toString()){toast("Minimum 4 characters and both must match");return@setOnClickListener}
            prefs.edit().putString("hash",hash(p.text.toString())).putBoolean("setup",true).apply()
            login()
        }
        setContentView(box)
    }

    private fun login(){
        box=base();title("🔒 Unlock Vault")
        val p=EditText(this).apply{hint="PIN / Password";inputType=0x81}
        box.addView(p)
        val b=Button(this).apply{text="Unlock"}
        val f=Button(this).apply{text="Use Fingerprint"}
        box.addView(b);box.addView(f)
        b.setOnClickListener{if(hash(p.text.toString())==prefs.getString("hash","")) refreshDashboard() else toast("Wrong PIN/password")}
        f.setOnClickListener{
            val ex=ContextCompat.getMainExecutor(this)
            val bp=BiometricPrompt(this,ex,object:BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){refreshDashboard()}
                override fun onAuthenticationError(c:Int,s:CharSequence){toast(s.toString())}
            })
            bp.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Life").setSubtitle("Use device fingerprint/biometric").setNegativeButtonText("Cancel").build())
        }
        setContentView(box)
    }

    private fun refreshDashboard(){
        box=base();title("Life")
        text("Files are stored in the app's private storage. They are not uploaded to a server.")
        addCat("🎬 Videos","video/*","video")
        addCat("🖼 Photos","image/*","image")
        addCat("🎵 Audio","audio/*","audio")
        addCat("📁 Other / Files","*/*","other")
        val list=Button(this).apply{text="📦 Open Vault"}
        box.addView(list);list.setOnClickListener{vaultList()}
        val restore=Button(this).apply{text="↩ Restore All"}
        box.addView(restore);restore.setOnClickListener{restoreAll()}
        val note=TextView(this).apply{text="⚠ Before uninstall: use Restore All. Android cannot run the app after it is uninstalled.";setPadding(0,20,0,10)}
        box.addView(note)
        setContentView(box)
    }

    private fun addCat(label:String,mime:String,type:String){
        val b=Button(this).apply{text="$label   + Add"}
        box.addView(b);b.setOnClickListener{currentType=type;picker.launch(arrayOf(mime))}
    }

    private fun vaultList(){
        box=base();title("📦 Vault")
        val arr=load()
        if(arr.length()==0) text("Vault is empty.")
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i)
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8)}
            val name=TextView(this).apply{text=o.optString("name");textSize=17f}
            row.addView(name)
            val open=Button(this).apply{text="Open / Play"}
            val restore=Button(this).apply{text="Unhide / Restore"}
            row.addView(open);row.addView(restore);box.addView(row)
            open.setOnClickListener{openItem(o)}
            restore.setOnClickListener{restoreItem(o)}
        }
        val back=Button(this).apply{text="← Dashboard"};box.addView(back);back.setOnClickListener{refreshDashboard()}
        setContentView(box)
    }

    private fun moveIntoVault(uri:Uri,type:String){
        try{
            val name=queryName(uri)?:("file_"+System.currentTimeMillis())
            val ext=name.substringAfterLast('.', "")
            val dir=File(filesDir,"vault/$type").apply{mkdirs()}
            var dest=File(dir,name)
            if(dest.exists()) dest=File(dir,System.currentTimeMillis().toString()+"_"+name)
            contentResolver.openInputStream(uri)?.use{input->
                FileOutputStream(dest).use{out->input.copyTo(out)}
            } ?: throw IOException("Cannot read source")
            if(dest.length()<=0) throw IOException("Empty copy")
            val verified=dest.inputStream().use{it.read()!=-1}
            if(!verified) throw IOException("Verification failed")

            // Delete original only AFTER successful copy.
            var deleted=false
            try { deleted=DocumentsContract.deleteDocument(contentResolver,uri) } catch(_:Throwable){}
            if(!deleted) {
                try { deleted=contentResolver.delete(uri,null,null)>0 } catch(_:Throwable){}
            }
            val arr=load()
            arr.put(JSONObject().apply{
                put("id",System.nanoTime().toString());put("name",name);put("type",type)
                put("path",dest.absolutePath);put("originalUri",uri.toString());put("originalDeleted",deleted)
            })
            save(arr)
            toast(if(deleted)"Moved to Vault and hidden from original location" else "Copied to Vault; Android did not allow deleting the original")
        }catch(e:Throwable){toast("Move failed: ${e.message}")}
    }

    private fun openItem(o:JSONObject){
        val file=File(o.optString("path"))
        if(!file.exists()){toast("Vault file missing");return}
        when(o.optString("type")){
            "image"->{
                val d=Dialog(this);val iv=ImageView(this)
                iv.setImageBitmap(BitmapFactory.decodeFile(file.absolutePath));iv.adjustViewBounds=true
                d.setContentView(iv);d.show()
            }
            "video"->{
                val d=Dialog(this);val v=VideoView(this)
                v.setVideoPath(file.absolutePath);v.setMediaController(android.widget.MediaController(this));v.start()
                d.setContentView(v);d.window?.setLayout(-1,-2);d.show()
            }
            "audio"->{
                val mp=android.media.MediaPlayer()
                mp.setDataSource(file.absolutePath);mp.prepare();mp.start()
                AlertDialog.Builder(this).setTitle(o.optString("name")).setMessage("Audio playing…").setOnDismissListener{mp.release()}.show()
            }
            else->toast("Private file: "+file.name)
        }
    }

    private fun restoreItem(o:JSONObject){
        val path=o.optString("path");val src=File(path)
        if(!src.exists()){toast("Vault file missing");return}
        val original=o.optString("originalUri",null)
        if(original.isNullOrEmpty()){toast("Original location not recorded");return}
        try{
            val uri=Uri.parse(original)
            // If the original document still exists and Android permits writing there,
            // overwrite it; otherwise ask the user to choose a destination.
            contentResolver.openOutputStream(uri,"w")?.use{out->src.inputStream().use{it.copyTo(out)}}
                ?: throw IOException("Original location unavailable")
            src.delete()
            val arr=load();removeById(arr,o.optString("id"));save(arr)
            toast("Restored to the original location")
            vaultList()
        }catch(e:Throwable){toast("Original location unavailable. Use export/restore to a new location.")}
    }

    private fun restoreAll(){
        val arr=load();var count=0
        for(i in arr.length()-1 downTo 0){
            val o=arr.getJSONObject(i)
            try{
                val src=File(o.optString("path"));val u=o.optString("originalUri")
                if(src.exists()&&u.isNotEmpty()){
                    contentResolver.openOutputStream(Uri.parse(u),"w")?.use{out->src.inputStream().use{it.copyTo(out)}}
                    src.delete();arr.remove(i);count++
                }
            }catch(_:Throwable){}
        }
        save(arr);toast("Restored $count file(s). Files whose original location is unavailable remain in Vault.")
    }

    private fun load():JSONArray=JSONArray(prefs.getString("items","[]"))
    private fun save(a:JSONArray){prefs.edit().putString("items",a.toString()).apply()}
    private fun removeById(a:JSONArray,id:String){for(i in a.length()-1 downTo 0)if(a.getJSONObject(i).optString("id")==id)a.remove(i)}
    private fun queryName(uri:Uri):String?{
        contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{
            if(it.moveToFirst())return it.getString(0)
        };return null
    }
    private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,20,30,20)}
    private fun title(s:String){box.addView(TextView(this).apply{text=s;textSize=28f;setPadding(0,15,0,20)})}
    private fun text(s:String){box.addView(TextView(this).apply{text=s;textSize=16f;setPadding(0,5,0,15)})}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}

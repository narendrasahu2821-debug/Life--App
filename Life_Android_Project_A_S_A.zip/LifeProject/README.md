# Life

Android private media vault project.

App name: **Life**

App icon: black background with white **A.S.A.** lettering, included inside the project at `app/src/main/res/drawable/ic_life.png`.

Build the APK with Android Studio or a compatible Android build environment.
